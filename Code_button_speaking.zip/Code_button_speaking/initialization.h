// initializations.h
#ifndef INITIALIZATION_H
#define INITIALIZATION_H


const int MPU = 0x68;
float AccX, AccY, AccZ, GyroX, GyroY, GyroZ;
float AccX1 = 0, AccY1 = 0, AccZ1 = 0, GyroX1 = 0, GyroY1 = 0, GyroZ1 = 0;
float AccX_filter, AccY_filter, AccZ_filter, GyroX_filter, GyroY_filter, GyroZ_filter;
float AccX1_filter = 0, AccY1_filter = 0, AccZ1_filter = 0, GyroX1_filter = 0, GyroY1_filter = 0, GyroZ1_filter = 0;
float AccAngleX, AccAngleY, AccAngleZ, GyroAngleX, GyroAngleY;
float roll, pitch, yaw;
float AccErrorX = 0.0, AccErrorY = 0.0, AccErrorZ = 0.0;
float GyroErrorX = 0.0, GyroErrorY = 0.0, GyroErrorZ = 0.0;
float AccAngleXE, AccAngleYE, AccAngleZE, GyroAngleXE, GyroAngleYE;
float pitchError = 0, rollError = 0, yawError = 0;
float deltaTime, currentTime = 0.0, previousTime = 0.0;
float accX = 0, accY = 0, accZ = 0;
float accErrorX = 0, accErrorY = 0, accErrorZ = 0;
float AngleX = 0.0;
float AngleY = 0.0;
const int calibrationSamples = 1000;
float time_Acc;
float t_record = 0;
float GestureTime = 0;
int i = 0;
float sum_GyroX = 0.0, sum_GyroY = 0.0, sum_GyroZ = 0.0;
float ratio_record = 0.0;
float X_Y, X_Z, Y_X, Y_Z, Z_X, Z_Y;
float a_1 = 0.999, b_1 = 0.000628, b_2 = 0.000628;  //transfer function coeifficient
int oriX = 0, oriY = 0, oriZ = 0;

int data[12] = {0,0,0,0,0,0,0,0,0,0,0,0};
float record = 0;
int level1 = 0;

const int numLevels = 3;             // Number of levels for gesture recognition
const float VCC = 5.0;               // VCC voltage (in volts)

// Flex Sensors
const int flexPin[6] = {A0,A2,A1,A3,A4,A5};
const int lowerBound[6] = {270,275,320,275,265,310};
const int upperBound[6] = {340,530,540,450,320,380};

int levels[6] = {0,0,0,0,0,0};           // levels initialization
int sensorValue = 0, V = 0, R = 0, angle = 0;  



// button & LED & SD
const int chipSelect = 53;
const int buttonPin = 10; 
const int LEDPin1 = 7;
const int LEDPin2 = 8;
int buttonState = 0;
int pre_buttonState = 0;
bool measure = false;
const int sd = 0;

#endif // INITIALIZATION_H