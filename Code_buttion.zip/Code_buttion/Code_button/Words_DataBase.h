// Words_DataBase.h
#ifndef WORDS_DATABASE_H
#define WORDS_DATABASE_H

const int hello[2][13] = {{3, 1, 1, 1, 1,     -1, 0, 0, 1,     -1, 0, -1,    1},{7, 3, 3, 3, 3,     4, 1, 1, 2,     5, 2, 2,     5}};
const int good[2][13] = {{1, 1, 1, 1, 1,     -1, 0, 1, 0,     -1, 0, -1,    1},{3, 3, 3, 3, 3,    2, 2, 2, 2,     5, 5, 5,     5}};
const int H_A_Y[2][13] = {{1, 1, 3, 3, 3,     -1, 0, 0, 1,     -1, 0, -1,      1},{3, 6, 5, 5, 5,     4, 1, 1, 2,     5, 2, 2,    5}};
const int words[3] = {hello, good, H_A_Y}; 
int size = sizeof(words) / sizeof(words[0]);

#endif // WORDS_DATABASE_H